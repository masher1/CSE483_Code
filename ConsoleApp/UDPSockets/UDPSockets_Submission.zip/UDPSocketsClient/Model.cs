﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
// Sockets
using System.Net.Sockets;
using System.Net;

namespace UDPSockets
{
    class Model : INotifyPropertyChanged
    {

        public event PropertyChangedEventHandler PropertyChanged;
        private void OnPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        private string _MessageText;
        public string MessageText
        {
            get{ return _MessageText; }
            set{
                _MessageText = value;
                OnPropertyChanged("MessageText");
            }
        }

        private String _StatusBox;
        public String StatusBox

        {
            get { return _StatusBox; }
            set
            {
                _StatusBox = value;
                OnPropertyChanged("StatusBox");
            }
        }

        public Model()
        {
            try
            {
                // set up generic UDP socket and bind to local port
                _dataSocket = new UdpClient();
            }
            catch (Exception ex)
            {
                StatusBox = (ex.ToString());
                return;
            }

        }

        // some data that keeps track of ports and addresses
        private UInt32 _remotePort = 5000;
        private String _remoteIPAddress = "127.0.0.1";

        // this is the UDP socket that will be used to communicate
        // over the network
        private UdpClient _dataSocket;

        public void SendMessage()
        {
            IPEndPoint remoteHost = new IPEndPoint(IPAddress.Parse(_remoteIPAddress), (int)_remotePort);
            Byte[] sendBytes = Encoding.ASCII.GetBytes(MessageText);
            StatusBox = "";
            try
            {
                _dataSocket.Send(sendBytes, sendBytes.Length, remoteHost);
                StatusBox = ("\"" + MessageText + "\" Successfully Sent Over!");
            }
            catch (SocketException ex)
            {
                StatusBox = ex.ToString();
                return;
            }
        }
    }
}